/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y51
 */

#ifndef trik_alsa_sound_dsp__
#define trik_alsa_sound_dsp__



#endif /* trik_alsa_sound_dsp__ */ 
